﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Pacman
{
	enum DIRECTION : byte
	{
		right = 1,
		left = 2,
		down = 3,
		up = 4
	}
	class Pacman
	{
		public int x { get; set; }
		public int y { get; set; }
		public DIRECTION direction { get; set; }
		public static readonly int RADIUS = 20;
		public int speed { get; set; }
		public bool isOpen { get; set; }
		Brush brush;

		public Pacman()
		{
			speed = RADIUS;
			x = 7; y = 5;
			brush = new SolidBrush(Color.Yellow);
			direction = DIRECTION.right;
		}
		public void ChangeDirection(DIRECTION d)
		{
			direction = d;
		}
		public void Move()
		{
			switch (direction)
			{
				case DIRECTION.right:
				{
						x++;
						if (x > 14) x = 0;
				} break;

				case DIRECTION.left:
				{
						x--;
						if (x < 0) x = 14;
				} break;

				case DIRECTION.up:
				{
					y--;
					if (y < 0) y = 9;
				} break;

				case DIRECTION.down:
				{
					y++;
					if (y > 9) y = 0;
				} break;
			}
		}
		public void Draw(Graphics g)
		{
			if (isOpen) g.FillPie(brush, x, y, RADIUS, RADIUS, 30, 120);
			else g.FillEllipse(brush, x, y, RADIUS, RADIUS);
		}
	}
}
