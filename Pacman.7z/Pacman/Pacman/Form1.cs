﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using Pacman.Properties;

namespace Pacman
{
	public partial class Form1 : Form
	{
		Pacman pacman;
		static readonly int TIMER_INTERVAL = 250;
		static readonly int WORLD_WIDTH = 15;
		static readonly int WORLD_HEIGHT = 10;
		Image foodImage;
		bool[,] foodWorld;
		public Form1()
		{
			InitializeComponent();
			foodImage = Resources.fruit;
			DoubleBuffered = true;
			newGame();
		}
		public void newGame()
		{
			pacman = new Pacman();
			this.Width = Pacman.RADIUS * 2 * (WORLD_WIDTH + 1);
			this.Height = Pacman.RADIUS * 2 * (WORLD_HEIGHT + 1);
			// овде кодот за иницијализација на матрицата foodWorld
			foodWorld = new Boolean[WORLD_WIDTH,WORLD_HEIGHT];
			for (int i = 0; i < WORLD_WIDTH; i++)
				for (int j = 0; j < WORLD_HEIGHT; j++)
					foodWorld[i,j] = true;
			// овде кодот за иницијализација и стартување на тајмерот
			timer1.Interval = TIMER_INTERVAL;
			timer1.Start();
		}
		void timer_Tick(object sender, EventArgs e)
		{
			// овде вашиот код
			foodWorld[pacman.x, pacman.y] = false;
			pacman.Move();
			Invalidate();
		}
		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void Form1_KeyUp(object sender, KeyEventArgs e)
		{
			switch (e.KeyData)
			{
				case Keys.Up:
					pacman.ChangeDirection(DIRECTION.up);
					break;
				case Keys.Down:
					pacman.ChangeDirection(DIRECTION.down);
					break;
				case Keys.Left:
					pacman.ChangeDirection(DIRECTION.left);
					break;
				case Keys.Right:
					pacman.ChangeDirection(DIRECTION.right);
					break;
				case Keys.Escape:
					this.Close();
					break;
			}
			Invalidate();
		}
		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			g.Clear(Color.White);
			for (int i = 0; i < WORLD_WIDTH; i++)
			{
				for (int j = 0; j < WORLD_HEIGHT; j++)
				{
					if (foodWorld[i,j])
					{
						g.DrawImageUnscaled(foodImage, j * Pacman.RADIUS * 2 + (Pacman.RADIUS * 2 - foodImage.Height) / 2, i * Pacman.RADIUS * 2 + (Pacman.RADIUS * 2 - foodImage.Width) / 2);
					}
				}
			}
			pacman.Draw(g);
		}
	}
}
